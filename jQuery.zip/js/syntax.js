// syntax.js

$(function() {

   // to hide the box
   // $('#box').hide();

    // fade out the triangle
   // $('.thing').fadeOut();

   // change the h1 color
   // $('h1').css("color", "blue");

    // button will only function if you click it.
   $("button").click(function() {
        $('#box').fadeOut(1000);
   });

});