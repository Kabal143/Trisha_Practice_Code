// script.js

$(function() {

    alert("hello?");
});