// selectors.js

$(function() {


   // $('h2,h3,h4').css('border', 'solid 1px red'); 

   // $('div#container').css('border','solid 1px red');

   // $('p.lead').css('border','solid 1px red');

   // $('li:first').css('border', 'solid 1px red');
   // $('li:last').css('border', 'solid 1px red');

   // $('p:even').css('border', 'solid 1px red');
   // $('p:odd').css('border', 'solid 1px red');


   // descendants selector
   // $('div em').css('border', 'solid 1px red');


   // selecting only child elements not descendants
   // $('div > p').css('border', 'solid 1px red');

   // $(':header').css('border', 'solid 1px red');

   // $(':contains("Trisha")').css('border', 'solid 1px red');

    // $('div:contains("Trisha")').css('border', 'solid 1px red');

});
   