// script.js


// DRAGGABLE
// https://jqueryui.com/draggable
$(function() {
    $('.box').draggable();
    $('#box1').draggable({ scroll: true });
    $('#box2').draggable({ axis: "x" });
    $('#box3').draggable({ axis: "y" });
    $('#box4').draggable({ containment: "parent" });
    // in Draggable containment, you can use .container or parent. You can use a class or id here if you want to be very specific.

    // DROPPABLE
    // https://jqueryui.com/draggable/
    $('#droppable').droppable({
        accept: '#box1',
        drop: function() {
            $(this).text("when a box got attitude, drop it like it's hot!");
        }
    });

    // if you dragged it to other place and not the right box, it will go back to it's original position.
    $('#box1').draggable({ scroll: true, revert: "invalid" });

    // it doesn't accept the DROP HERE box because it's not acceptable.
   // $('#box4').draggable({ containment: "parent", revert: "invalid" });

    // but if you say valid, the box 4 will stay at DRAG Me box.
    $('#box4').draggable({ containment: "parent", revert: "valid" });


    // SORTABLE
    // https://jqueryui.com/sortable/
    $('#sortable').sortable({ connectWith: "#sortableToo", placeholder: "placeholderBox" });
    $('#sortableToo').sortable({ connectWith: "#sortable", placeholder: "placeholderBox" });



    // ACCORDION
    // https://jqueryui.com/accordion/
    $('#accordion').accordion({ collapsible: "true", heightStyle: "content" });



    // DATEPICKER
    // https://jqueryui.com/datepicker/
    $('.date').datepicker({
        showOtherMonths: true,
        selectOtherMonths: true,
        showButtonPanel: true,
        changeMonth: true,
        changeYear: true,
        numberOfMonths: 2,
        minDate: 0,
        maxDate: "+1W + 5D"
    });

    // TO DO LIST
    // https://jqueryui.com/datepicker/
    $('#todolist ul').sortable({
        items: "li:not('.listTitle, .addItem')",
        connectWith: "ul",
        dropOnEmpty: true,
        placeholder: "emptySpace"
    });

    $('input').keydown(function(e) {
        if(e.keyCode == 13) {
            var item = $(this).val();

            $(this).parent().parent().append('<li>' + item + '</li>');
            $(this).val('');
        }
    });

    $('#trash').droppable({
        drop: function(event, ui) {
        ui.draggable.remove();
        }
    });
    

});