/* Script.js */

/* sample of external JavaScript */
var currentDate = new Date ();

window.alert(currentDate);


